package com.example.myapplication;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void handleText(View v) {
        EditText t = findViewById(R.id.source);
        String input = t.getText().toString();
        ((TextView)findViewById(R.id.output)).setText(input);

        Log.d("info", input);
    }

    public void disable(View v) {
        findViewById(R.id.button1).setEnabled(false);
        ((Button)findViewById(R.id.button1)).setText("Boat22");
        Log.d("Success", "Great Job!");



        /* modify variables individually
        //
        View myView = findViewById(R.id.button1);
        myView.setEnabled(false);
        Button button1 = (Button)myView;
        button1.setText("Disabled");
         */




       /* modify variables generally
       //
        v.setEnabled(false);
        Log.d("success", "Button Disabled");
        Button b = (Button) v;
        b.setText("disabled");
        */

    }
}
