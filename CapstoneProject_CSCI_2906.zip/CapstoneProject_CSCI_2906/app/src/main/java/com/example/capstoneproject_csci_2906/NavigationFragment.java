package com.example.capstoneproject_csci_2906;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import com.google.android.material.navigation.NavigationView;

public class NavigationFragment extends Fragment implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout mDrawerLayout;

    public NavigationFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_navigation, container, false);
        NavigationView navigationView = view.findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mDrawerLayout = requireActivity().findViewById(R.id.drawer_layout);

        return view;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }

    /*
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_main) {
            // Handle the main action
        } else if (id == R.id.nav_love) {
            // Handle the love action
        } else if (id == R.id.nav_work) {
            // Handle the work action
        } else if (id == R.id.nav_learning) {
            // Handle the learning action
        } else if (id == R.id.nav_play) {
            // Handle the play action
        } else if (id == R.id.nav_health) {
            // Handle the health action
        } else if (id == R.id.nav_safety) {
            // Handle the safety action
        } else if (id == R.id.nav_summary) {
            // Handle the summary action
        }

        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;

     */

}
